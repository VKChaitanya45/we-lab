const users = [
  {
    "userId": 1,
    "name": "Pranay Kumar",
    "age": 21,
    "contact": 9381244438
  },
  {
    "userId": 2,
    "name": "Nikhil Chandra",
    "age": 20,
    "contact": 8394568236
  },
  {
    "userId": 3,
    "name": "Ritin",
    "age": 21,
    "contact": 862145638
  },
  {
    "userId": 4,
    "name": "Prasuna",
    "age": 20,
    "contact": 8569456328
  },
  {
    "userId": 5,
    "name": "Chotu",
    "age": 19,
    "contact": 8934587329
  },
  {
    "userId": 7,
    "name": "Yelchu",
    "age": 69
  }
]
module.exports = users;